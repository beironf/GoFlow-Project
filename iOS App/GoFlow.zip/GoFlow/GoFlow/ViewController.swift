//
//  ViewController.swift
//  GoFlow
//
//  Created by Fredrik Beiron on 05/05/16.
//  Copyright © 2016 Fredrik Beiron. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var scrollView: UIScrollView!
    
    var descriptionText: String?
    var exerciseTitle: String?
    var connectionTitle: String?
    var calPlaceholder: String?
    var repNumber: Int = 10
    var exerciseImage: UIImage?
    var isTimeExercise: Bool = true
    var exerciseNr: Int?
    var isKinectExercise: Bool = true
    var host: String = "beirons-macbook-pro.local"
    
    // Table variables
    var addToTableBool: Bool = false
    var tableName: String?
    var tableAverage: String?
    var tableImage: UIImage?
    var data: [[Double]]?
    var tableExercise: String?
    
    
    // Server
    var conn: Connection!
    var connectStatusServer = false
    
    
    let vc0 = ViewController0(nibName: "ViewController0", bundle: nil)
    let vc1 = ViewController1(nibName: "ViewController1", bundle: nil)
    let vc2 = ViewController2(nibName: "ViewController2", bundle: nil)
    let vc3 = ViewController3(nibName: "ViewController3", bundle: nil)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        makeLayout()
        setUpScroll()
        makeRecognizer()
        
        if addToTableBool == true {
            //do {
            self.vc0.addTableItem(self.tableName!, tblAverage: self.tableAverage!, tblImage: self.tableImage!, data: data!, exercise: self.tableExercise!)
            //}
            //catch {print("can't add to table")}
        }
    }
    

    
    
    
    func makeRecognizer() {
        let tapGesture1 = UITapGestureRecognizer(target: self, action: #selector(ViewController.exerciseButtonPressed1))
        let tapGesture2 = UITapGestureRecognizer(target: self, action: #selector(ViewController.exerciseButtonPressed2))
        let tapGesture3 = UITapGestureRecognizer(target: self, action: #selector(ViewController.exerciseButtonPressed3))
        let tapGesture4 = UITapGestureRecognizer(target: self, action: #selector(ViewController.exerciseButtonPressed4))
        let tapGesture5 = UITapGestureRecognizer(target: self, action: #selector(ViewController.exerciseButtonPressed5))
        let tapGesture6 = UITapGestureRecognizer(target: self, action: #selector(ViewController.exerciseButtonPressed6))
        let tapGesture7 = UITapGestureRecognizer(target: self, action: #selector(ViewController.exerciseButtonPressed7))
        let tapGesture8 = UITapGestureRecognizer(target: self, action: #selector(ViewController.exerciseButtonPressed8))
        let tapGesture9 = UITapGestureRecognizer(target: self, action: #selector(ViewController.exerciseButtonPressed9))
        let tapGesture10 = UITapGestureRecognizer(target: self, action: #selector(ViewController.exerciseButtonPressed10))
        let tapGesture11 = UITapGestureRecognizer(target: self, action: #selector(ViewController.exerciseButtonPressed11))
        let tapGesture12 = UITapGestureRecognizer(target: self, action: #selector(ViewController.exerciseButtonPressed12))
        self.vc2.ovn1.addGestureRecognizer(tapGesture1)
        self.vc2.ovn2.addGestureRecognizer(tapGesture2)
        self.vc2.ovn3.addGestureRecognizer(tapGesture3)
        self.vc2.ovn4.addGestureRecognizer(tapGesture4)
        self.vc2.ovn5.addGestureRecognizer(tapGesture5)
        self.vc2.ovn6.addGestureRecognizer(tapGesture6)
        self.vc3.ovn7.addGestureRecognizer(tapGesture7)
        self.vc3.ovn8.addGestureRecognizer(tapGesture8)
        self.vc3.ovn9.addGestureRecognizer(tapGesture9)
        self.vc3.ovn10.addGestureRecognizer(tapGesture10)
        self.vc3.ovn11.addGestureRecognizer(tapGesture11)
        self.vc3.ovn12.addGestureRecognizer(tapGesture12)
    }
    
    func exerciseButtonPressed1() {
        descriptionText = "In this exercise you should place the kinect camera perpendicular towards a surface and try to hit a specific green target. Use the computer program to get the right camera angle. Press start between each throw."
        repNumber = 10
        connectionTitle = "Connect to computer"
        exerciseTitle = "Throw Against Target"
        exerciseImage = UIImage(named: "exercise1")
        isTimeExercise = false
        exerciseNr = 1
        isKinectExercise = true
        self.performSegueWithIdentifier("showExercise", sender: self)
    }
    func exerciseButtonPressed2() {
    }
    func exerciseButtonPressed3() {
        descriptionText = "In this exercise you should move a ball between the two green lines 10 times as fast as possible. You can choose between using your feets or bouncing the ball to move it. The kinect camera should be placed according to the image above and the ball should be visible to the camera. The time starts when the ball passes the first line and not when you press the start button."
        repNumber = 10
        connectionTitle = "Connect to computer"
        exerciseTitle = "Fast Turns"
        exerciseImage = UIImage(named: "exercise3")
        isTimeExercise = true
        exerciseNr = 3
        isKinectExercise = true
        self.performSegueWithIdentifier("showExercise", sender: self)
    }
    func exerciseButtonPressed4() {
        descriptionText = "In this exercise you should drop a ball from a specific height of your own choice and then try to move the ball as fast as possible into a green circle, only by using your feets. The kinect camera should be facing the practitioner and try not to block the ball for the camera. The time starts when you press the start button and ends when the ball have been inside the circle two consecutive seconds."
        repNumber = 10
        connectionTitle = "Connect to computer"
        exerciseTitle = "Move To Circle"
        exerciseImage = UIImage(named: "exercise4")
        isTimeExercise = true
        exerciseNr = 4
        isKinectExercise = true
        self.performSegueWithIdentifier("showExercise", sender: self)
    }
    func exerciseButtonPressed5() {
    }
    func exerciseButtonPressed6() {
        descriptionText = "In this exercise you should roll the ball and try to make it stop as close to a green target as possible. The kinect camera should see the target and the target zone. Press start between each roll."
        repNumber = 10
        connectionTitle = "Connect to computer"
        exerciseTitle = "Roll To Target"
        exerciseImage = UIImage(named: "exercise6")
        isTimeExercise = false
        exerciseNr = 6
        isKinectExercise = true
        self.performSegueWithIdentifier("showExercise", sender: self)
    }
    func exerciseButtonPressed7() {
        descriptionText = "In this exercise you should place the kinect camera perpendicular towards a surface and try to hit a specific green target. Use the computer program to get the right camera angle. Press start between each throw."
        repNumber = 10
        connectionTitle = "Connect to computer"
        exerciseTitle = "Shoot Against Target"
        exerciseImage = UIImage(named: "exercise1")
        isTimeExercise = false
        exerciseNr = 7
        isKinectExercise = true
        self.performSegueWithIdentifier("showExercise", sender: self)
    }
    func exerciseButtonPressed8() {
    }
    func exerciseButtonPressed9() {
        descriptionText = "In this exercise you should move a ball between the two green lines 10 times as fast as possible. You can choose between using your feets or bouncing the ball to move it. The kinect camera should be placed according to the image above and the ball should be visible to the camera. The time starts when the ball passes the first line and not when you press the start button."
        repNumber = 10
        connectionTitle = "Connect to computer"
        exerciseTitle = "Fast Turns"
        exerciseImage = UIImage(named: "exercise3")
        isTimeExercise = true
        exerciseNr = 9
        isKinectExercise = true
        self.performSegueWithIdentifier("showExercise", sender: self)
    }
    func exerciseButtonPressed10() {
        descriptionText = "In this exercise you should drop a ball from a specific height of your own choice and then try to move the ball as fast as possible into a green circle, only by using your feets. The kinect camera should be facing the practitioner and try not to block the ball for the camera. The time starts when you press the start button and ends when the ball have been inside the circle two consecutive seconds."
        repNumber = 10
        connectionTitle = "Connect to computer"
        exerciseTitle = "Move To Circle"
        exerciseImage = UIImage(named: "exercise4")
        isTimeExercise = true
        exerciseNr = 10
        isKinectExercise = true
        self.performSegueWithIdentifier("showExercise", sender: self)
    }
    func exerciseButtonPressed11() {
        descriptionText = "In this exercise you should try to balance the custom made GoFlow°-ball on a racket or a stick for as long as possible. The time starts when you press the start button. No camera needed."
        repNumber = 10
        connectionTitle = "Connect to ball"
        exerciseTitle = "Equipment Balance"
        exerciseImage = UIImage(named: "exerciseBalance")
        isTimeExercise = true
        exerciseNr = 11
        isKinectExercise = false
        self.performSegueWithIdentifier("showExercise", sender: self)
    }
    func exerciseButtonPressed12() {
        descriptionText = "In this exercise you should roll the ball and try to make it stop as close to a green target as possible. The kinect camera should see the target and the target zone. Press start between each roll."
        repNumber = 10
        connectionTitle = "Connect to computer"
        exerciseTitle = "Roll To Target"
        exerciseImage = UIImage(named: "exercise6")
        isTimeExercise = false
        exerciseNr = 12
        isKinectExercise = true
        self.performSegueWithIdentifier("showExercise", sender: self)
    }
    
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if(segue.identifier == "showExercise") {
            let vc_ny = (segue.destinationViewController as! ExerciseViewController)
            vc_ny.descriptionText = self.descriptionText!
            vc_ny.repNumberVar = self.repNumber
            vc_ny.connectionTitle = self.connectionTitle
            vc_ny.exerciseTitleVar = self.exerciseTitle
            vc_ny.exerciseImage = self.exerciseImage
            vc_ny.isTimeExercise = self.isTimeExercise
            vc_ny.exerciseNr = self.exerciseNr
            vc_ny.isKinectExercise = self.isKinectExercise
            vc_ny.host = self.host
        }
    }
    
    
    
    func makeLayout() {
        
        UIApplication.sharedApplication().statusBarStyle = .LightContent
        
        
        self.addChildViewController(vc0)
        self.scrollView.addSubview(vc0.view)
        vc0.didMoveToParentViewController(self)
        
        var frame1 = vc1.view.frame
        frame1.origin.x = self.view.frame.size.width // * frame number
        vc1.view.frame = frame1
        
        self.addChildViewController(vc1)
        self.scrollView.addSubview(vc1.view)
        vc1.didMoveToParentViewController(self)
        
        
        var frame2 = vc2.view.frame
        frame2.origin.x = self.view.frame.size.width * 2 // * frame number
        vc2.view.frame = frame2
        
        self.addChildViewController(vc2)
        self.scrollView.addSubview(vc2.view)
        vc2.didMoveToParentViewController(self)
        
        
        var frame3 = vc3.view.frame
        frame3.origin.x = self.view.frame.size.width * 3 // * frame number
        vc3.view.frame = frame3
        
        self.addChildViewController(vc3)
        self.scrollView.addSubview(vc3.view)
        vc3.didMoveToParentViewController(self)
        
        self.scrollView.contentSize = CGSizeMake(self.view.frame.size.width * 4, self.view.frame.size.height - 22) // * number of pages
        self.scrollView.contentOffset.x = self.view.frame.size.width
    }
    
    func setUpScroll() {
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = false
        scrollView.pagingEnabled = true
        scrollView.bounces = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

