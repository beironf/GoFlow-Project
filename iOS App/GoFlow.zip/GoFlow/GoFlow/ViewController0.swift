//
//  ViewController0.swift
//  BollApp2
//
//  Created by Fredrik Beiron on 11/02/16.
//  Copyright © 2016 Fredrik Beiron. All rights reserved.
//

import UIKit
import MessageUI

class ViewController0: UIViewController , UITableViewDataSource, UITableViewDelegate, TableViewCellDelegate, MFMailComposeViewControllerDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var dataMessage: UILabel!
    @IBOutlet weak var mailButton: UIImageView!
    @IBOutlet weak var deleteButton: UIImageView!
    
    var tableItems = [TableItem]()
    var selectedRowIndex = -1
    
    var path1: NSURL?
    var path2: NSURL?
    var path3: NSURL?
    var path4: NSURL?
    
    var pathOK: Bool = false
    
    let file1: String = "data1.tsv" //this is the files we save the data to and attach when sending e-mail
    let file2: String = "data2.tsv"
    let file3: String = "data3.tsv"
    let file4: String = "data4.tsv"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tapGestureMail = UITapGestureRecognizer(target: self, action: #selector(ViewController0.sendMail))
        self.mailButton.addGestureRecognizer(tapGestureMail)
        let tapGestureDelete = UITapGestureRecognizer(target: self, action: #selector(ViewController0.deleteAllElements))
        self.deleteButton.addGestureRecognizer(tapGestureDelete)
        
        tableView.dataSource = self
        tableView.delegate = self
        tableView.registerClass(TableViewCell.self, forCellReuseIdentifier: "cell")
        
        // Register custom cell
        let nib = UINib(nibName: "nibCell", bundle: nil)
        tableView.registerNib(nib, forCellReuseIdentifier: "cell")
        
        //self.tableView.tableFooterView = UIView(frame: CGRectZero)  // Remove "cells" after last cell
        
        // Load data
        let defaults = NSUserDefaults.standardUserDefaults()
        if let savedData = defaults.objectForKey("tableItems") as? NSData {
            tableItems = NSKeyedUnarchiver.unarchiveObjectWithData(savedData) as! [TableItem]
        }
        if tableItems.count == 0 {
            dataMessage.text = "You don't have any saved data."
        } else {
            dataMessage.text = ""
        }
        
        
        if let dir = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.AllDomainsMask, true).first {
            path1 = NSURL(fileURLWithPath: dir).URLByAppendingPathComponent(file1)
            path2 = NSURL(fileURLWithPath: dir).URLByAppendingPathComponent(file2)
            path3 = NSURL(fileURLWithPath: dir).URLByAppendingPathComponent(file3)
            path4 = NSURL(fileURLWithPath: dir).URLByAppendingPathComponent(file4)
            pathOK = true
        }
    }
    
    
    func addTableItem(tblName: String, tblAverage: String, tblImage: UIImage, data: [[Double]], exercise: String) {
        tableItems.append(TableItem(cellName: tblName, cellAverage: tblAverage, cellImage: tblImage, data: data, cellExercise: exercise))
        self.save()
        dataMessage.text = ""
    }
    
    func deleteAllElements(sender: AnyObject) {
        if self.tableItems.count == 0 {
            showNoDataToDeleteErrorAlert()
            return
        }
        let deleteAllNotification = UIAlertController(title: "Delete All Saved Data?", message: "Are you sure you want to delete all saved data?", preferredStyle: .Alert)
        let YESAction = UIAlertAction(title: "YES", style: .Default) { (action) in
            let lastIndex = self.tableItems.count-1
            for i in 0...self.tableItems.count-1 {
                self.tableItems.removeAtIndex(lastIndex-i)
                self.tableView.beginUpdates()
                let indexPathForRow = NSIndexPath(forRow: lastIndex-i, inSection: 0)
                self.tableView.deleteRowsAtIndexPaths([indexPathForRow], withRowAnimation: .Fade)
                self.tableView.endUpdates()
                self.save()
            }
            self.dataMessage.text = "You don't have any saved data."
        }
        let NOAction = UIAlertAction(title: "NO", style: .Default) { (action) in
            // ...
        }
        deleteAllNotification.addAction(NOAction)
        deleteAllNotification.addAction(YESAction)
        self.presentViewController(deleteAllNotification, animated: true) {
            // ...
        }
    }
    
    func sendMail(sender: AnyObject) {
        if (tableItems.count > 0) {
            let mailComposeViewController = configuredMailComposeViewController()
            if MFMailComposeViewController.canSendMail() {
                self.presentViewController(mailComposeViewController, animated: true, completion: nil)
            } else {
                self.showSendMailErrorAlert()
            }
        } else {
            showNoDataToSendErrorAlert()
        }
    }
    
    func showNoDataToSendErrorAlert() {
        let NoDataToSendErrorAlert = UIAlertController(title: "No data to send", message: nil, preferredStyle: .Alert)
        let OKAction = UIAlertAction(title: "OK", style: .Default) { (action) in
        }
        NoDataToSendErrorAlert.addAction(OKAction)
        self.presentViewController(NoDataToSendErrorAlert, animated: true) {
            // ...
        }
    }
    
    func showNoDataToDeleteErrorAlert() {
        let NoDataToDeleteErrorAlert = UIAlertController(title: "No data to delete", message: nil, preferredStyle: .Alert)
        let OKAction = UIAlertAction(title: "OK", style: .Default) { (action) in
        }
        NoDataToDeleteErrorAlert.addAction(OKAction)
        self.presentViewController(NoDataToDeleteErrorAlert, animated: true) {
            // ...
        }
    }
    
    func configuredMailComposeViewController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        
        //mailComposerVC.setToRecipients([""])
        mailComposerVC.setSubject("Sending you data from the GoFlow° app")
        mailComposerVC.setMessageBody("<p>The data is structured as follows:</p> <ul><li>data1 - Time exercises (simple)</li><li>data2 - Time exercises</li><li>data3 - Distance exercises (simple)</li><li>data4 - Distance exercises</li></ul>", isHTML: true)
        
        if (pathOK) {
            self.clearData(path1!)
            self.setData(path1!, nr: 1)
            self.clearData(path2!)
            self.setData(path2!, nr: 2)
            self.clearData(path3!)
            self.setData(path3!, nr: 3)
            self.clearData(path4!)
            self.setData(path4!, nr: 4)

            if let fileData = NSData(contentsOfURL: path1!) {
                //print("File data loaded.")
                mailComposerVC.addAttachmentData(fileData, mimeType: "text/tsv", fileName: "data1.tsv")
            }
            if let fileData = NSData(contentsOfURL: path2!) {
                //print("File data loaded.")
                mailComposerVC.addAttachmentData(fileData, mimeType: "text/tsv", fileName: "data2.tsv")
            }
            if let fileData = NSData(contentsOfURL: path3!) {
                //print("File data loaded.")
                mailComposerVC.addAttachmentData(fileData, mimeType: "text/tsv", fileName: "data3.tsv")
            }
            if let fileData = NSData(contentsOfURL: path4!) {
                //print("File data loaded.")
                mailComposerVC.addAttachmentData(fileData, mimeType: "text/tsv", fileName: "data4.tsv")
            }
        }
        return mailComposerVC
    }
    
    func clearData(path: NSURL) {
        let emptyText = ""
        do {
            try emptyText.writeToURL(path, atomically: false, encoding: NSUTF8StringEncoding)
        }
        catch {print("Error while clearing datafiles")}
    }
    
    func setData(path: NSURL, nr: Int) {
        var dataString = ""
        if tableItems.count == 0 {
            return
        }
        for i in 0...tableItems.count-1 {
            if (i == 0) {
                if (nr == 1) {
                    dataString = dataString + "Name" + "\t" + "Exercise" + "\t" + "Quantity" + "\t" + "Average (s)" + "\t" + "Total (s)" + "\n"
                } else if (nr == 2) {
                    dataString = dataString + "Name" + "\t" + "Exercise" + "\t" + "Order" + "\t" + "Time (s)" + "\n"
                } else if (nr == 3) {
                    dataString = dataString + "Name" + "\t" + "Exercise" + "\t" + "Quantity" + "\t" + "Average (m)" + "\n"
                } else if (nr == 4) {
                    dataString = dataString + "Name" + "\t" + "Exercise" + "\t" + "Order" + "\t" + "x-value (m)" + "\t" + "y-value (m)" + "\t" + "distance (m)" + "\n"
                }
            }
            
            if (tableItems[i].exercise == "Roll To Target") {
                if nr == 3 { // Simple distance exercises
                    let s1:String = tableItems[i].name + "\t" + tableItems[i].exercise + "\t" + String(tableItems[i].data.count)
                    let s2:String = "\t" + tableItems[i].average + "\n"
                    dataString = dataString + s1 + s2
                    
                } else if nr == 4 { // Full distance exercises
                    for j in 0...tableItems[i].data.count-1 {
                        let s1:String = tableItems[i].name + "\t" + tableItems[i].exercise + "\t" + "\(j+1)" + "\t" + "" + "\t" + "" + "\t" + String(tableItems[i].data[j][0]) + "\n"
                        dataString = dataString + s1
                    }
                }
            } else if tableItems[i].data[0].count == 1 {            // time exercise
                if nr == 1 {        // Simple time exercises
                    let s1:String = tableItems[i].name + "\t" + tableItems[i].exercise + "\t" + String(tableItems[i].data.count)
                    let s2:String = "\t" + tableItems[i].average + "\t"
                    let average: Double = (tableItems[i].average as NSString).doubleValue
                    let s3:String = String(average*Double(tableItems[i].data.count)) + "\n"
                    dataString = dataString + s1 + s2 + s3
                    
                } else if nr == 2 { // Full time exercises
                    for j in 0...tableItems[i].data.count-1 {
                        let s1:String = tableItems[i].name + "\t" + tableItems[i].exercise + "\t" + "\(j+1)" + "\t" + String(tableItems[i].data[j][0]) + "\n"
                        dataString = dataString + s1
                    }
                }
            } else if tableItems[i].data[0].count == 3 {     // distance exercise
                if nr == 3 { // Simple distance exercises
                    let s1:String = tableItems[i].name + "\t" + tableItems[i].exercise + "\t" + String(tableItems[i].data.count)
                    let s2:String = "\t" + tableItems[i].average + "\n"
                    dataString = dataString + s1 + s2
                    
                } else if nr == 4 { // Full distance exercises
                    for j in 0...tableItems[i].data.count-1 {
                        let s1:String = tableItems[i].name + "\t" + tableItems[i].exercise + "\t" + "\(j+1)" + "\t" + String(tableItems[i].data[j][0]) + "\t" + String(tableItems[i].data[j][1]) + "\t" + String(tableItems[i].data[j][2]) + "\n"
                        dataString = dataString + s1
                    }
                }
            }
        }
        do {
            try dataString.writeToURL(path, atomically: false, encoding: NSUTF8StringEncoding)
        }
        catch{print("Error while setData()")}
    }
    
    func showSendMailErrorAlert() {
        let sendMailErrorAlert = UIAlertController(title: "Could Not Send Email", message: "Your device could not send e-mail.  Please check e-mail configuration and try again.", preferredStyle: .Alert)
        let OKAction = UIAlertAction(title: "OK", style: .Default) { (action) in
            // ...
        }
        sendMailErrorAlert.addAction(OKAction)
        self.presentViewController(sendMailErrorAlert, animated: true) {
            // ...
        }
    }

    // MARK: MFMailComposeViewControllerDelegate Method
    func mailComposeController(controller: MFMailComposeViewController, didFinishWithResult result: MFMailComposeResult, error: NSError?) {
        controller.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func save() {
        let savedData = NSKeyedArchiver.archivedDataWithRootObject(tableItems)
        let defaults = NSUserDefaults.standardUserDefaults()
        defaults.setObject(savedData, forKey: "tableItems")
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableItems.count
    }
    
    func tableView(tableView: UITableView,
        cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)
                as! TableViewCell
            let item = tableItems[indexPath.row]
            cell.name.text = item.name
            cell.average.text = item.average
            cell.imageExercise.image = item.image
            cell.backgroundColor = UIColor.clearColor()
            cell.delegate = self
            cell.tableItem = item
            return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        self.selectedRowIndex = indexPath.row
        // Remove all text from other cells
        for i in 0...tableItems.count-1 {
            if let cell = tableView.cellForRowAtIndexPath(NSIndexPath(forRow: i, inSection: 0)) as? TableViewCell {
                //print("count:  \(tableItems.count)   i:   \(i)   row:  \(NSIndexPath(forRow: i, inSection: 0).row)   section:   \(NSIndexPath(forRow: i, inSection: 0).section)")
                let cellArray: [UILabel] = [cell.label1, cell.label2, cell.label3, cell.label4, cell.label5, cell.label6, cell.label7, cell.label8, cell.label9, cell.label10, cell.label11, cell.label12, cell.label13, cell.label14, cell.label15, cell.label16, cell.label17, cell.label18, cell.label19, cell.label20]
                cell.ovnLabel.text = ""
                for j in 0...19 {
                    cellArray[j].text = ""
                }
            }
        }
        // Add text to the selected cell
        let cell = tableView.cellForRowAtIndexPath(indexPath) as! TableViewCell
        cell.ovnLabel.text = tableItems[indexPath.row].exercise
        let cellArray: [UILabel] = [cell.label1, cell.label2, cell.label3, cell.label4, cell.label5, cell.label6, cell.label7, cell.label8, cell.label9, cell.label10, cell.label11, cell.label12, cell.label13, cell.label14, cell.label15, cell.label16, cell.label17, cell.label18, cell.label19, cell.label20]
        let rows = tableItems[indexPath.row].data.count
        let cols = tableItems[indexPath.row].data[0].count
        for i in 0...rows-1 {
            var nr = tableItems[indexPath.row].data[i][cols-1]
            nr = round(100*nr)/100
            cellArray[i].text = "Rep \(i+1):   \(nr)"
        }
        
        // update all the cells
        self.tableView.beginUpdates()
        self.tableView.endUpdates()
    }
    
    func tableView(tableView: UITableView, didDeselectRowAtIndexPath indexPath: NSIndexPath) {
        self.selectedRowIndex = -1
        // Remove all text from cells
        for i in 0...tableItems.count-1 {
            if let cell = tableView.cellForRowAtIndexPath(NSIndexPath(forRow: i, inSection: 0)) as? TableViewCell {
                let cellArray: [UILabel] = [cell.label1, cell.label2, cell.label3, cell.label4, cell.label5, cell.label6, cell.label7, cell.label8, cell.label9, cell.label10, cell.label11, cell.label12, cell.label13, cell.label14, cell.label15, cell.label16, cell.label17, cell.label18, cell.label19, cell.label20]
                cell.ovnLabel.text = ""
                for j in 0...19 {
                    cellArray[j].text = ""
                }
            }
        }
        // update all the cells
        self.tableView.beginUpdates()
        self.tableView.endUpdates()
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath
        indexPath: NSIndexPath) -> CGFloat {
            let horizontalClass = self.traitCollection.horizontalSizeClass
            
            switch (horizontalClass) {
            case .Regular :
                if self.selectedRowIndex == indexPath.row {
                    return 300
                }
                return 110
            case .Compact :
                if self.selectedRowIndex == indexPath.row {
                    return 200
                }
                return 64.5
            default :
                if self.selectedRowIndex == indexPath.row {
                    return 200
                }
                return 64.5
            }
    }
    
    func tableItemDeleted(tableItem: TableItem) {
        let index = (tableItems as NSArray).indexOfObject(tableItem)
        if index == NSNotFound { return }
        
        // could removeAtIndex in the loop but keep it here for when indexOfObject works
        tableItems.removeAtIndex(index)
        
        // use the UITableView to animate the removal of this row
        tableView.beginUpdates()
        let indexPathForRow = NSIndexPath(forRow: index, inSection: 0)
        tableView.deleteRowsAtIndexPaths([indexPathForRow], withRowAnimation: .Fade)
        tableView.endUpdates()
        self.save()
        if tableItems.count == 0 {
            dataMessage.text = "You don't have any saved data."
        }
    }
    
    
    // MARK: NSCoding
    
    
    
    
    //func colorForIndex(index: Int) -> UIColor {
    //    let itemCount = tableItems.count - 1
    //    let val = (CGFloat(index) / CGFloat(itemCount)) * 0.4
    //    return UIColor(red: 0.40-val, green: 0.75-val, blue: 0.35-val, alpha: 1.0)
    //}
    
    //func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell,
    //    forRowAtIndexPath indexPath: NSIndexPath) {
    //       cell.backgroundColor = colorForIndex(indexPath.row)
    //}
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    

}
