//
//  Connection.swift
//  GoFlow
//
//  Created by Fredrik Beiron on 05/05/16.
//  Copyright © 2016 Fredrik Beiron. All rights reserved.
//

import Foundation

protocol ConnectionDelegate {
    func serverDidConnect(sender: Connection, stream: NSStream)
    func serverDidDisconnect(sender: Connection, s: String)
    func serverDidReceiveValue(sender: Connection, dataMsg: String)
    func serverIsOffline(sender: Connection, s: String)
}

class Connection: NSObject, NSStreamDelegate {
    var delegate: ConnectionDelegate?
    
    var host:String?
    var port:Int?
    var inputStream: NSInputStream?
    var outputStream: NSOutputStream?
    var dataToSend: String?
    
    func connect(host: String, port: Int) {
        
        self.host = host
        self.port = port
        
        NSStream.getStreamsToHostWithName(host, port: port, inputStream: &inputStream, outputStream: &outputStream)
        
        if inputStream != nil && outputStream != nil {
            
            // Set delegate
            inputStream!.delegate = self
            outputStream!.delegate = self
            
            // Schedule
            inputStream!.scheduleInRunLoop(.mainRunLoop(), forMode: NSDefaultRunLoopMode)
            outputStream!.scheduleInRunLoop(.mainRunLoop(), forMode: NSDefaultRunLoopMode)
            
            //print("Start open()")
            
            // Open!
            inputStream!.open()
            outputStream!.open()
        }
    }
    
    func sendData(data: String) {
        self.dataToSend = data
        self.stream(outputStream!, handleEvent: NSStreamEvent.HasSpaceAvailable)
    }
    
    func stream(aStream: NSStream, handleEvent eventCode: NSStreamEvent) {
        switch eventCode {
        case NSStreamEvent.ErrorOccurred:
            //print("input: ErrorOccurred: \(aStream.streamError?.description)")
            delegate?.serverIsOffline(self, s: "Server offline")
            break
        case NSStreamEvent.None:
            //print("input: No events occured")
            delegate?.serverIsOffline(self, s: "Server offline")
            break
        case NSStreamEvent.EndEncountered:
            //print("input: Connection ended")
            delegate?.serverDidDisconnect(self,s: "Server disconnected")
            break
        case NSStreamEvent.OpenCompleted:
            //print("input: OpenCompleted")
            delegate?.serverDidConnect(self,stream: aStream)
            break
        case NSStreamEvent.HasBytesAvailable:
            //print("input: HasBytesAvailable")
            var buffer = [UInt8](count: 4096, repeatedValue: 0)
            if aStream == inputStream {
                while (inputStream!.hasBytesAvailable){
                    let len = inputStream!.read(&buffer, maxLength: buffer.count)
                    if(len > 0){
                        if let input = NSString(bytes: &buffer, length: buffer.count, encoding: NSUTF8StringEncoding) {
                            let trimmedInput: String = (input as String).stringByTrimmingCharactersInSet(
                                NSCharacterSet.whitespaceAndNewlineCharacterSet())
                            delegate?.serverDidReceiveValue(self, dataMsg: trimmedInput)
                        }
                    }
                }
            }
            break
        case NSStreamEvent.HasSpaceAvailable:
            //print("output: HasSpaceAvailable")
            if let s: String = dataToSend {
                let data: NSData = s.dataUsingEncoding(NSUTF8StringEncoding)!
                outputStream!.write(UnsafePointer<UInt8>(data.bytes), maxLength: data.length)
            }
            dataToSend = nil
            break
        default:
            break
        }
    }
}