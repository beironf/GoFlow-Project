//
//  TableViewCell.swift
//  BollApp2
//
//  Created by Fredrik Beiron on 12/02/16.
//  Copyright © 2016 Fredrik Beiron. All rights reserved.
//

import UIKit
//import QuartzCore

// A protocol that the TableViewCell uses to inform its delegate of state change
protocol TableViewCellDelegate {
    // indicates that the given item has been deleted
    func tableItemDeleted(tableItem: TableItem)
}

class TableViewCell: UITableViewCell {
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var average: UILabel!
    @IBOutlet weak var imageExercise: UIImageView!
    @IBOutlet weak var ovnLabel: UILabel!
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label3: UILabel!
    @IBOutlet weak var label4: UILabel!
    @IBOutlet weak var label5: UILabel!
    @IBOutlet weak var label6: UILabel!
    @IBOutlet weak var label7: UILabel!
    @IBOutlet weak var label8: UILabel!
    @IBOutlet weak var label9: UILabel!
    @IBOutlet weak var label10: UILabel!
    @IBOutlet weak var label11: UILabel!
    @IBOutlet weak var label12: UILabel!
    @IBOutlet weak var label13: UILabel!
    @IBOutlet weak var label14: UILabel!
    @IBOutlet weak var label15: UILabel!
    @IBOutlet weak var label16: UILabel!
    @IBOutlet weak var label17: UILabel!
    @IBOutlet weak var label18: UILabel!
    @IBOutlet weak var label19: UILabel!
    @IBOutlet weak var label20: UILabel!
    
    
    var originalCenter = CGPoint()
    var deleteOnDragRelease = false
    var delegate: TableViewCellDelegate?
    var tableItem: TableItem?
    var crossLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        // add a pan recognizer
        let recognizer = UIPanGestureRecognizer(target: self, action: #selector(TableViewCell.handlePan(_:)))
        recognizer.delegate = self
        addGestureRecognizer(recognizer)
        
        // tick and cross labels for context cues
        crossLabel = createCueLabel()
        addSubview(crossLabel)
    }
    
    // utility method for creating the contextual cues
    func createCueLabel() -> UILabel {
        let label = UILabel(frame: CGRect.null)
        label.textColor = UIColor.clearColor()
        label.font = UIFont.boldSystemFontOfSize(40.0)
        label.backgroundColor = UIColor.redColor()
        label.text = "\u{2717}" // 2717
        label.textAlignment = .Right
        label.alpha = CGFloat(0.0)
        return label
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        crossLabel.frame = CGRect(x: -bounds.size.width, y: 0,
            width: bounds.size.width, height: bounds.size.height)
    }
    
    //MARK: - horizontal pan gesture methods
    func handlePan(recognizer: UIPanGestureRecognizer) {
        if recognizer.state == .Began {
            // when the gesture begins, record the current center location
            originalCenter = center
        }
        if recognizer.state == .Changed {
            let translation = recognizer.translationInView(self)
            center = CGPointMake(originalCenter.x + translation.x, originalCenter.y)
            // has the user dragged the item far enough to initiate a delete/complete?
            deleteOnDragRelease = frame.origin.x > frame.size.width / 2.0
        }
        if recognizer.state == .Ended {
            // the frame this cell had before user dragged it
            let originalFrame = CGRect(x: 0, y: frame.origin.y,
                width: bounds.size.width, height: bounds.size.height)
            if !deleteOnDragRelease {
                // if the item is not being deleted, snap back to the original location
                UIView.animateWithDuration(0.2, animations: {self.frame = originalFrame})
            }
            if deleteOnDragRelease {
                if delegate != nil && tableItem != nil {
                    // notify the delegate that this item should be deleted
                    delegate!.tableItemDeleted(tableItem!)
                }
            }
        }
        // fade the contextual clues
        let cueAlpha = fabs(frame.origin.x) / (frame.size.width / 2.0)
        crossLabel.alpha = cueAlpha
        // indicate when the user has pulled the item far enough to invoke the given action
        crossLabel.textColor = deleteOnDragRelease ? UIColor.whiteColor() : UIColor.clearColor()
    }
    
    override func gestureRecognizerShouldBegin(gestureRecognizer: UIGestureRecognizer) -> Bool {
        if let panGestureRecognizer = gestureRecognizer as? UIPanGestureRecognizer {
            let translation = panGestureRecognizer.translationInView(superview!)
            if fabs(translation.x) > fabs(translation.y) {
                let vel: CGPoint = panGestureRecognizer.velocityInView(self.viewForFirstBaselineLayout)
                if vel.x > 0 {
                    return true
                }
            }
            return false
        }
        return false
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    
        // Configure the view for the selected state
    }

    
    //let gradientLayer = CAGradientLayer()
    
    //required init(coder aDecoder: NSCoder) {
    //    fatalError("NSCoding not supported")
    //}
    
    //override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
    //    super.init(style: style, reuseIdentifier: reuseIdentifier)
    //
    //    // gradient layer for cell
    //    gradientLayer.frame = bounds
    //    let color1 = UIColor(white: 1.0, alpha: 0.2).CGColor as CGColorRef
    //    let color2 = UIColor(white: 1.0, alpha: 0.1).CGColor as CGColorRef
    //    let color3 = UIColor.clearColor().CGColor as CGColorRef
    //    let color4 = UIColor(white: 0.0, alpha: 0.1).CGColor as CGColorRef
    //    gradientLayer.colors = [color1, color2, color3, color4]
    //    gradientLayer.locations = [0.0, 0.01, 0.95, 1.0]
    //    layer.insertSublayer(gradientLayer, atIndex: 0)
    //}
    
    //override func layoutSubviews() {
    //    super.layoutSubviews()
    //    gradientLayer.frame = bounds
    //}
}
