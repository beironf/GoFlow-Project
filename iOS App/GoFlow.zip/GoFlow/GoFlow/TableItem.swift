//
//  TableItem.swift
//  BollApp2
//
//  Created by Fredrik Beiron on 12/02/16.
//  Copyright © 2016 Fredrik Beiron. All rights reserved.
//

import UIKit

class TableItem: NSObject, NSCoding {
    // A text description of this item.
    var name: String
    var image: UIImage
    var average: String
    var data: [[Double]]
    var exercise: String
    // A Boolean value that determines the completed state of this item.
    var completed: Bool
    
    required init(coder aDecoder: NSCoder) {
        name = aDecoder.decodeObjectForKey("name") as! String
        image = aDecoder.decodeObjectForKey("image") as! UIImage
        average = aDecoder.decodeObjectForKey("average") as! String
        data = aDecoder.decodeObjectForKey("data") as! [[Double]]
        completed = aDecoder.decodeObjectForKey("completed") as! Bool
        exercise = aDecoder.decodeObjectForKey("exercise") as! String
    }
    
    func encodeWithCoder(aCoder: NSCoder) {
        aCoder.encodeObject(name, forKey: "name")
        aCoder.encodeObject(image, forKey: "image")
        aCoder.encodeObject(average, forKey: "average")
        aCoder.encodeObject(data, forKey: "data")
        aCoder.encodeObject(completed, forKey: "completed")
        aCoder.encodeObject(exercise, forKey: "exercise")
    }
    
    // Returns a tableItem initialized with the given text and default completed value.
    init(cellName: String, cellAverage: String, cellImage: UIImage, data: [[Double]], cellExercise: String) {
        self.name = cellName
        self.completed = false
        self.image = cellImage
        self.average = cellAverage
        self.data = data
        self.exercise = cellExercise
    }
}
