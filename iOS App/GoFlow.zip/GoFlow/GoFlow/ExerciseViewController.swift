//
//  ExerciseViewController.swift
//  GoFlow
//
//  Created by Fredrik Beiron on 05/05/16.
//  Copyright © 2016 Fredrik Beiron. All rights reserved.
//

import UIKit

class ExerciseViewController: UIViewController, BLEDelegate, ConnectionDelegate, UITextFieldDelegate {
    
    
    @IBOutlet weak var cancel: UIImageView!
    @IBOutlet weak var exerciseDescription: UILabel!
    @IBOutlet weak var startButton: UIImageView!
    @IBOutlet weak var imageExercise: UIImageView!
    @IBOutlet weak var exerciseTitle: UILabel!
    @IBOutlet weak var connectionMsg: UILabel!
    @IBOutlet weak var repNumber: UITextField!
    @IBOutlet weak var buttonText: UILabel!
    @IBOutlet weak var averageNumber: UILabel!
    @IBOutlet weak var nameInput: UITextField!
    @IBOutlet weak var imageArea: UIImageView!
    @IBOutlet weak var connectButton: UIImageView!
    
    @IBOutlet weak var time1: UILabel!
    @IBOutlet weak var time2: UILabel!
    @IBOutlet weak var time3: UILabel!
    @IBOutlet weak var time4: UILabel!
    @IBOutlet weak var time5: UILabel!
    @IBOutlet weak var time6: UILabel!
    @IBOutlet weak var time7: UILabel!
    @IBOutlet weak var time8: UILabel!
    @IBOutlet weak var time9: UILabel!
    @IBOutlet weak var time10: UILabel!
    
    @IBOutlet weak var pos1: UILabel!
    @IBOutlet weak var pos2: UILabel!
    @IBOutlet weak var pos3: UILabel!
    
    // constraints
    var pos1ConstraintX: NSLayoutConstraint!
    var pos1ConstraintY: NSLayoutConstraint!
    var pos2ConstraintX: NSLayoutConstraint!
    var pos2ConstraintY: NSLayoutConstraint!
    var pos3ConstraintX: NSLayoutConstraint!
    var pos3ConstraintY: NSLayoutConstraint!
    var origo_x: Double = 0.0
    var origo_y: Double = 0.0
    
    var timeLabels: [UILabel] = []
    var posLabels: [UILabel] = []
    
    var descriptionText: String?
    var exerciseTitleVar: String?
    var connectionTitle: String?
    var repNumberVar: Int = 10
    var exerciseImage = UIImage?()
    var boolCalHidden: Bool = true
    var averageNum: String = ""
    var isTimeExercise: Bool = true
    var exerciseNr: Int?
    var isKinectExercise: Bool = true
    
    var isWaitingForValue: Bool = false
    
    // BLE:
    var ble: BLE!
    var connectStatusBLE:Bool = false
    let ballUUID:String = "9125C031-5A43-1A43-1C02-F13C79A0765B"
    
    // Server
    var conn: Connection!
    var connectStatusServer = false
    var host: String?
    
    
    
    var count: Int = 0
    var isDoneWithAllRep: Bool = false
    let maxNrOfRep: Int = 20
    
    var exerciseWidth: Double?
    var exerciseHeight: Double?
    let viewXMax: Double = 1.0
    let viewYMax: Double = 1.0 * 0.56851549755302
    
    
    // Person variables
    var rows: Int = 10
    var cols: Int = 1
    var data = [[Double]]()
    var data2 = [[Double]]()
    var rowOfAbsMax: Int?
    var colOfAbsMax: Int?
    
    
    
    
    // ----------------------------------- View did load ------------------------------------
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tapGestureCancel = UITapGestureRecognizer(target: self, action: #selector(ExerciseViewController.cancelPressed))
        let tapGestureStart = UITapGestureRecognizer(target: self, action: #selector(ExerciseViewController.startPressed))
        self.cancel.addGestureRecognizer(tapGestureCancel)
        self.startButton.addGestureRecognizer(tapGestureStart)
        
        let tapToConnectToDevice = UITapGestureRecognizer(target: self, action: #selector(self.connectToDevice))
        self.connectButton.addGestureRecognizer(tapToConnectToDevice)
        
        exerciseDescription.text = descriptionText
        imageExercise.image = exerciseImage
        connectionMsg.text = connectionTitle
        exerciseTitle.text = exerciseTitleVar
        repNumber.text = String(repNumberVar)
        buttonText.text = "Start"
        averageNumber.text = averageNum
        
        
        if (!isTimeExercise && exerciseNr! != 6 && exerciseNr! != 12) {
            cols = 3
        }
        
        // time labels
        timeLabels.append(time1)
        timeLabels.append(time2)
        timeLabels.append(time3)
        timeLabels.append(time4)
        timeLabels.append(time5)
        timeLabels.append(time6)
        timeLabels.append(time7)
        timeLabels.append(time8)
        timeLabels.append(time9)
        timeLabels.append(time10)
        
        if (UIScreen.mainScreen().traitCollection.horizontalSizeClass == UIUserInterfaceSizeClass.Compact) {
            // iPhone
            origo_x = Double(self.view.frame.size.width/2)
            origo_y = Double(65 + self.view.frame.size.width*697/1226/2)
            //print("\(origo_x)" + " x " + "\(origo_y)")
            print("iPhone")
        } else {
            // iPad
            origo_x = Double(self.view.frame.size.width/2)
            origo_y = Double(85 + self.view.frame.size.width*697/1226/2)
            //print("\(origo_x)" + " x " + "\(origo_y)")
            print("iPad")
        }
        
        // position labels
        posLabels.append(pos1)
        posLabels.append(pos2)
        posLabels.append(pos3)
        
        pos1ConstraintX = NSLayoutConstraint(item:self.pos1,
                                             attribute:NSLayoutAttribute.Leading,
                                             relatedBy:NSLayoutRelation.Equal,
                                             toItem:self.view,
                                             attribute:NSLayoutAttribute.Leading,
                                             multiplier:1.0,
                                             constant:384);
        pos1ConstraintY = NSLayoutConstraint(item:self.pos1,
                                             attribute:NSLayoutAttribute.Top,
                                             relatedBy:NSLayoutRelation.Equal,
                                             toItem:self.view,
                                             attribute:NSLayoutAttribute.Top,
                                             multiplier:1.0,
                                             constant:303);
        pos2ConstraintX = NSLayoutConstraint(item:self.pos2,
                                             attribute:NSLayoutAttribute.Leading,
                                             relatedBy:NSLayoutRelation.Equal,
                                             toItem:self.view,
                                             attribute:NSLayoutAttribute.Leading,
                                             multiplier:1.0,
                                             constant:350);
        pos2ConstraintY = NSLayoutConstraint(item:self.pos2,
                                             attribute:NSLayoutAttribute.Top,
                                             relatedBy:NSLayoutRelation.Equal,
                                             toItem:self.view,
                                             attribute:NSLayoutAttribute.Top,
                                             multiplier:1.0,
                                             constant:250);
        pos3ConstraintX = NSLayoutConstraint(item:self.pos3,
                                             attribute:NSLayoutAttribute.Leading,
                                             relatedBy:NSLayoutRelation.Equal,
                                             toItem:self.view,
                                             attribute:NSLayoutAttribute.Leading,
                                             multiplier:1.0,
                                             constant:430);
        pos3ConstraintY = NSLayoutConstraint(item:self.pos3,
                                             attribute:NSLayoutAttribute.Top,
                                             relatedBy:NSLayoutRelation.Equal,
                                             toItem:self.view,
                                             attribute:NSLayoutAttribute.Top,
                                             multiplier:1.0,
                                             constant:350);
        
        self.view.addConstraint(pos1ConstraintX);
        self.view.addConstraint(pos1ConstraintY);
        self.view.addConstraint(pos2ConstraintX);
        self.view.addConstraint(pos2ConstraintY);
        self.view.addConstraint(pos3ConstraintX);
        self.view.addConstraint(pos3ConstraintY);
        
        
        
        // Connection
        if (isKinectExercise) {
            //conn.delegate = self
        } else {
            ble = BLE()
            ble.controlSetup()
            ble.delegate = self;
        }
        
        // Text field delegate:
        repNumber!.delegate = self
        nameInput!.delegate = self
    }
    // --------------------------------------------------------------------------------------
    
    
    // Dismiss keyboard when hitting enter method:
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    
    // ------------------------------ Connect to ball or server -----------------------------
    
    // Connect method:
    
    func connectToDevice() {
        if (isKinectExercise) {
            if (!self.connectStatusServer) {
                showConnectToServerQuestion()
            }
        } else {  // is ball exercise
            if (!self.connectStatusBLE) {
                //showConnectToBallQuestion()
                if (ble.activePeripheral != nil) {
                    if (ble.activePeripheral.state == CBPeripheralState.Connected) {
                        ble.CM.cancelPeripheralConnection(ble.activePeripheral)
                        //return
                    }
                }
                if (ble.peripherals != nil) {
                    ble.peripherals = nil
                }
                self.connectionMsg.text = "Trying.."
                
                //ble.findServiceFromUUID("9125C031-5A43-1A43-1C02-F13C79A0765B", p: <#T##CBPeripheral!#>)
                
                ble.findBLEPeripherals(2)
                NSTimer.scheduledTimerWithTimeInterval(2.0, target: self, selector: #selector(ExerciseViewController.bleConnectionTimer), userInfo: nil, repeats: false)
                
            } else {
                //ble.CM.cancelPeripheralConnection(ble.activePeripheral) // Cancel connection
            }
        }
    }
    
    func connectToServer() {
        conn = Connection()
        conn.delegate = self
        conn.connect(host!, port: 3233)
    }
    
    // --------------------------------------------------------------------------------------
    
    
    // ---------------------------- Server methods ------------------------------------------
    
    // Connection Delegate:
    
    func serverDidConnect(sender: Connection, stream: NSStream) {
        if (stream is NSInputStream) {
            self.connectionMsg.text = "Connected"
            self.connectStatusServer = true
            print("Input delegate works!")
        } else if (stream is NSOutputStream) {
            print("Output delegate works!")
        }
    }
    
    func serverIsOffline(sender: Connection, s: String) {
        self.buttonText!.text = "Start"
        if (conn != nil) {
            conn.inputStream!.close()
            conn.outputStream!.close()
            conn.inputStream!.removeFromRunLoop(.mainRunLoop(), forMode: NSDefaultRunLoopMode)
            conn.outputStream!.removeFromRunLoop(.mainRunLoop(), forMode: NSDefaultRunLoopMode)
            conn = nil
        }
        print(s)
        showServerOfflineErrorAlert()
    }
    
    func serverDidDisconnect(sender: Connection, s: String) {
        self.connectionMsg.text = "Connect to computer"
        self.connectStatusServer = false
        self.buttonText!.text = "Start"
        if (conn != nil) {
            conn.inputStream!.close()
            conn.outputStream!.close()
            conn.inputStream!.removeFromRunLoop(.mainRunLoop(), forMode: NSDefaultRunLoopMode)
            conn.outputStream!.removeFromRunLoop(.mainRunLoop(), forMode: NSDefaultRunLoopMode)
            conn = nil
        }
        print(s)
        showServerDisconnectErrorAlert()
    }
    // --------------------------------------------------------------------------------------
    
    
    
    
    
    // ------------------------------- BLE methods ------------------------------------------
    
    func sendBLEData(data:String) {
        if (ble.activePeripheral.state == CBPeripheralState.Connected) {
            ble.write(data.dataUsingEncoding(NSUTF8StringEncoding))
        } else {
            showBLEDisconnectErrorAlert()
        }
    }
    
    // BLE Delegate
    
    func bleDidConnect() {
        self.connectionMsg.text = "Connected"
        connectStatusBLE = true
    }
    
    func bleDidDisconnect() {
        showBLEDisconnectErrorAlert()
        connectStatusBLE = false
        self.connectionMsg.text = "Connect to ball"
    }
    
    func bleConnectionTimer() {
        if (ble.peripherals != nil) {
            ble.printKnownPeripherals()
            
            self.ble.connectPeripheral(self.ble.peripherals.objectAtIndex(0) as! CBPeripheral)
            
            // Specific UUID:
//            for i in 0...(ble.peripherals.count-1) {
//                if let ballPeripheral:CBPeripheral = (self.ble.peripherals.objectAtIndex(i) as! CBPeripheral) {
//                    if (!ble.isConnected()) {
//                        print("\((ble.peripherals.objectAtIndex(i) as! CBPeripheral).identifier.UUIDString)")
//                        if ((ble.peripherals.objectAtIndex(i) as! CBPeripheral).identifier.UUIDString == ballUUID) {
//                            self.ble.connectPeripheral(ballPeripheral)
//                        }
//                    }
//                }
//            }
            
            NSTimer.scheduledTimerWithTimeInterval(2.0, target: self, selector: #selector(ExerciseViewController.didBLEFailToConnect), userInfo: nil, repeats: false)
        } else {
            self.showBLECouldNotFindErrorAlert()
            self.connectionMsg.text = "Connect to ball"
        }
    }
    
    func didBLEFailToConnect() {
        if (!ble.isConnected()) {
            self.showBLECouldNotFindErrorAlert()
            self.connectionMsg.text = "Connect to ball"
        }
    }
    // --------------------------------------------------------------------------------------
    
    
    // ------------------------------------ Server messages ----------------------------------
    
    func showConnectToServerQuestion() {
        let connectToServerQuestion = UIAlertController(title: ("Connect to the host: ''" + self.host! + "''?"), message: "Do you want to connect to this host or another?", preferredStyle: .Alert)
        let YESAction = UIAlertAction(title: "YES", style: .Default) { (action) in
            self.connectToServer()
        }
        let OTHERAction = UIAlertAction(title: "OTHER", style: .Default) { (action) in
            self.showConnectToOtherServer()
        }
        connectToServerQuestion.addAction(OTHERAction)
        connectToServerQuestion.addAction(YESAction)
        self.presentViewController(connectToServerQuestion, animated: true) {
            // ...
        }
    }

    
    func showConnectToOtherServer() {
        let connectToOtherServer = UIAlertController(title: "Connect To New Host", message: "", preferredStyle: UIAlertControllerStyle.Alert)
        
        let connectAction = UIAlertAction(title: "Connect", style: UIAlertActionStyle.Default, handler: {
            alert -> Void in
            
            let textField = connectToOtherServer.textFields![0] as UITextField
            self.host = textField.text!
            self.connectToServer()
        })
        
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Default, handler: {
            (action : UIAlertAction!) -> Void in
            
        })
        
        connectToOtherServer.addTextFieldWithConfigurationHandler { (textField : UITextField!) -> Void in
            textField.placeholder = "Enter Host"
        }
        
        connectToOtherServer.addAction(connectAction)
        connectToOtherServer.addAction(cancelAction)
        
        self.presentViewController(connectToOtherServer, animated: true, completion: nil)
    }
    
    
    // --------------------------------------------------------------------------------------
    
    
    // ------------------------------------ Error messages ----------------------------------
    
    func showServerDisconnectErrorAlert() {
        let serverDisconnectErrorAlert = UIAlertController(title: "Lost connection to Server", message: "You lost connection to the computer.  Please check the computer program and try to connect again.", preferredStyle: .Alert)
        let OKAction = UIAlertAction(title: "OK", style: .Default) { (action) in
            self.performSegueWithIdentifier("showMenu", sender: self)
        }
        serverDisconnectErrorAlert.addAction(OKAction)
        self.presentViewController(serverDisconnectErrorAlert, animated: true) {
            // ...
        }
    }
    
    func showServerOfflineErrorAlert() {
        let serverOfflineErrorAlert = UIAlertController(title: "The server is offline", message: "The server appears to be offline.  Please check the computer program and try to connect again.", preferredStyle: .Alert)
        let OKAction = UIAlertAction(title: "OK", style: .Default) { (action) in
            // ...
        }
        serverOfflineErrorAlert.addAction(OKAction)
        self.presentViewController(serverOfflineErrorAlert, animated: true) {
            // ...
        }
    }
    
    func showBLEDisconnectErrorAlert() {
        let BLEDisconnectErrorAlert = UIAlertController(title: "Lost connection to ball", message: "You lost connection to the ball.  Please check bluetooth configuration and try to conect again.", preferredStyle: .Alert)
        let OKAction = UIAlertAction(title: "OK", style: .Default) { (action) in
            // ...
        }
        BLEDisconnectErrorAlert.addAction(OKAction)
        self.presentViewController(BLEDisconnectErrorAlert, animated: true) {
            // ...
        }
    }
    
    func showBLECouldNotFindErrorAlert() {
        let BLECouldNotFindErrorAlert = UIAlertController(title: "Could not find the ball", message: "Couldn't find the ball. Please check bluetooth configuration and try to conect again. Charge the ball or turn off and on bluetooth may also help.", preferredStyle: .Alert)
        let OKAction = UIAlertAction(title: "OK", style: .Default) { (action) in
            // ...
        }
        BLECouldNotFindErrorAlert.addAction(OKAction)
        self.presentViewController(BLECouldNotFindErrorAlert, animated: true) {
            // ...
        }
    }
    
    func showBLECouldNotConnectErrorAlert() {
        let BLECouldNotConnectErrorAlert = UIAlertController(title: "Could not connect to the ball", message: "Couldn't connect to the ball. Please check bluetooth configuration and try to conect again. Charge the ball or turn off and on bluetooth may also help.", preferredStyle: .Alert)
        let OKAction = UIAlertAction(title: "OK", style: .Default) { (action) in
            // ...
        }
        BLECouldNotConnectErrorAlert.addAction(OKAction)
        self.presentViewController(BLECouldNotConnectErrorAlert, animated: true) {
            // ...
        }
    }
    
    func showServerNotConnectedErrorAlert() {
        let serverNotConnectedErrorAlert = UIAlertController(title: "You are not connected to server.", message: " Please try to connect with the connection button.", preferredStyle: .Alert)
        let OKAction = UIAlertAction(title: "OK", style: .Default) { (action) in
            // ...
        }
        serverNotConnectedErrorAlert.addAction(OKAction)
        self.presentViewController(serverNotConnectedErrorAlert, animated: true) {
            // ...
        }
    }
    
    func showBLENotConnectedErrorAlert() {
        let BLENotConnectedErrorAlert = UIAlertController(title: "You are not connected to ball.", message: " Please try to connect with the connection button.", preferredStyle: .Alert)
        let OKAction = UIAlertAction(title: "OK", style: .Default) { (action) in
            // ...
        }
        BLENotConnectedErrorAlert.addAction(OKAction)
        self.presentViewController(BLENotConnectedErrorAlert, animated: true) {
            // ...
        }
    }
    func showNotAValidNumberErrorAlert() {
        let notAValidNumberErrorAlert = UIAlertController(title: "Not a valid repetitons number.", message: "Change rep. to a valid number and try again.", preferredStyle: .Alert)
        let OKAction = UIAlertAction(title: "OK", style: .Default) { (action) in
            // ...
        }
        notAValidNumberErrorAlert.addAction(OKAction)
        self.presentViewController(notAValidNumberErrorAlert, animated: true) {
            // ...
        }
    }
    
    // -----------------------------------------------------------------------------------------
    
    
    
    // ----------------------- Update screen when an exercise is done --------------------------
    
    // BLE did receive:
    
    func bleDidReceiveData(receivedData: UnsafeMutablePointer<UInt8>, length: Int32) {
        if (isWaitingForValue) {
            if let dataMsg:NSString! = NSString(bytes: receivedData, length: Int(length), encoding: NSUTF8StringEncoding) {
                receivedData.destroy()
                print("Received Value: \(dataMsg!)")
                
                let time = (dataMsg! as NSString).doubleValue
                
                data[count][0] = time
                averageNumber.text = String(format: "%.1f s", getAverage())
                
                if count == 0 {
                    timeLabels[0].text = String(format: "%.1f", data[count][0])
                } else if count < 10 {
                    for i in 0...count-1 {
                        timeLabels[count-i].text = timeLabels[count-i-1].text
                    }
                    timeLabels[0].text = String(format: "%.1f", data[count][0])
                } else {
                    for i in 0...8 {
                        timeLabels[9-i].text = timeLabels[9-i-1].text
                    }
                    timeLabels[0].text = String(format: "%.1f", data[count][0])
                }
                NSTimer.scheduledTimerWithTimeInterval(2.0, target: self, selector: #selector(ExerciseViewController.SetIsWaitingForValueToFalse), userInfo: nil, repeats: false)
                //isWaitingForValue = false
                
                if (count != rows-1) {
                    self.buttonText!.text = "Start"
                } else {
                    self.buttonText!.text = "Save data"
                }
                count += 1
                
            } else {
                print("Wrong input from data send.")
            }
        } else {
            print("Data sent at wrong time.")
        }
    }
    
    
    // Server did receive:
    
    func serverDidReceiveValue(sender: Connection, dataMsg: String) {
        if (isWaitingForValue) {
            print("Received Value")
            if (dataMsg != "") {
                print(dataMsg)
                if (isTimeExercise) { // ----------------------------- Tidsövning
                    
                    let time = (dataMsg as NSString).doubleValue
                    
                    data[count][0] = time
                    averageNumber.text = String(format: "%.1f s", getAverage())
                    
                    if count == 0 {
                        timeLabels[0].text = String(format: "%.1f", data[count][0])
                    } else if count < 10 {
                        for i in 0...count-1 {
                            timeLabels[count-i].text = timeLabels[count-i-1].text
                        }
                        timeLabels[0].text = String(format: "%.1f", data[count][0])
                    } else {
                        for i in 0...8 {
                            timeLabels[9-i].text = timeLabels[9-i-1].text
                        }
                        timeLabels[0].text = String(format: "%.1f", data[count][0])
                    }
                    
                    if (exerciseNr! == 3 || exerciseNr! == 9) {
                        isWaitingForValue = true
                        if (count == rows-1) {
                            isDoneWithAllRep = true
                            isWaitingForValue = false
                        }
                    } else {
                        NSTimer.scheduledTimerWithTimeInterval(2.0, target: self, selector: #selector(ExerciseViewController.SetIsWaitingForValueToFalse), userInfo: nil, repeats: false)
                        //isWaitingForValue = false
                    }
                    
                    
                    
                } else if (isKinectExercise && exerciseNr! != 6 && exerciseNr! != 12) {    // --------------------------------------- Koordinatövning
                    
                    let dataArray = dataMsg.componentsSeparatedByString(":")
                    let x:Double = (dataArray[0] as NSString).doubleValue
                    let y:Double = (dataArray[1] as NSString).doubleValue
                    
                    data[count][0] = x
                    data[count][1] = y
                    data[count][2] = getR(x,y: y)
                    averageNumber.text = String(format: "%.2f m", getAverage())
                    
                    
                    // measurements of screen
                    exerciseWidth = Double(self.view.frame.size.width)/2
                    exerciseHeight = exerciseWidth!*0.56851549755302
                    let xMax = exerciseWidth!*0.8
                    let yMax = exerciseHeight!*0.8
                    
                    
                    // Set texts
                    switch (count) { // How many elements should we work with?
                    case 0: // count
                        // labels
                        posLabels[0].text = String(format: "°%.2f", getR(data[count][0],y: data[count][1]))
                        
                    case 1: // count
                        // labels
                        posLabels[1].text = posLabels[0].text
                        posLabels[0].text = String(format: "°%.2f", getR(data[count][0],y: data[count][1]))
                        
                    default: // count
                        for i in 0...1 {
                            posLabels[2-i].text = posLabels[1-i].text
                        }
                        posLabels[0].text = String(format: "°%.2f", getR(data[count][0],y: data[count][1]))
                    }
                    
                    // Set constraints
                    let posConstraints: [NSLayoutConstraint] = [self.pos1ConstraintX, self.pos1ConstraintY, self.pos2ConstraintX, self.pos2ConstraintY, self.pos3ConstraintX, self.pos3ConstraintY]
                    var nrOfElements = 0
                    if count > 2 {
                        nrOfElements = 2
                    } else {
                        nrOfElements = count
                    }
                    for i in 1...(nrOfElements+1)*2 {
                        if i==1 || i==3 || i==5 {   // X Constraint
                            if abs(data[count-Int((i-1)/2)][0]) > viewXMax {  // Outside the view
                                let tempConst = data[count-Int((i-1)/2)][0]/abs(data[count-Int((i-1)/2)][0])*xMax
                                posConstraints[i-1].constant = CGFloat(origo_x + tempConst)
                                posLabels[Int((i-1)/2)].textColor = UIColor.redColor()
                            } else {
                                posConstraints[i-1].constant = CGFloat(origo_x+data[count-Int((i-1)/2)][0]/viewXMax*xMax)
                                posLabels[Int((i-1)/2)].textColor = UIColor.whiteColor()
                            }
                        } else {                    // Y Constraint
                            if abs(data[count-Int((i-2)/2)][1]) > viewYMax {  // Outside the view
                                let tempConst = data[count-Int((i-2)/2)][1]/abs(data[count-Int((i-2)/2)][1])*yMax
                                posConstraints[i-1].constant = CGFloat(origo_y - tempConst)
                                posLabels[Int((i-2)/2)].textColor = UIColor.redColor()
                            } else {
                                posConstraints[i-1].constant = CGFloat(origo_y - data[count-Int((i-1)/2)][1]/viewYMax*yMax)
                                if abs(data[count-Int((i-1)/2)][0]) < viewXMax {
                                    posLabels[Int((i-2)/2)].textColor = UIColor.whiteColor()
                                }
                            }
                        }
                    }
                    self.view.layoutIfNeeded()
                    NSTimer.scheduledTimerWithTimeInterval(2.0, target: self, selector: #selector(ExerciseViewController.SetIsWaitingForValueToFalse), userInfo: nil, repeats: false)
                    //isWaitingForValue = false
                    
                    
                    
                } else {    // --------------------------------------- Avståndsövning (roll to target)
                    
                    let r = (dataMsg as NSString).doubleValue
                    
                    data[count][0] = r
                    averageNumber.text = String(format: "%.1f m", getAverage())
                    
                    if count == 0 {
                        timeLabels[0].text = String(format: "%.1f", data[count][0])
                    } else if count < 10 {
                        for i in 0...count-1 {
                            timeLabels[count-i].text = timeLabels[count-i-1].text
                        }
                        timeLabels[0].text = String(format: "%.1f", data[count][0])
                    } else {
                        for i in 0...8 {
                            timeLabels[9-i].text = timeLabels[9-i-1].text
                        }
                        timeLabels[0].text = String(format: "%.1f", data[count][0])
                    }
                    NSTimer.scheduledTimerWithTimeInterval(2.0, target: self, selector: #selector(ExerciseViewController.SetIsWaitingForValueToFalse), userInfo: nil, repeats: false)
                    //isWaitingForValue = false
                }
                
                if (count != rows-1 && exerciseNr! != 3 && exerciseNr! != 9) {
                    self.buttonText!.text = "Start"
                } else if (count != rows-1) {
                    // keep "waiting"
                } else {
                    self.buttonText!.text = "Save data"
                }
                count += 1
            }
        }
    }
    // ---------------------------------------------------------------------------------------

    
    func SetIsWaitingForValueToFalse() {
        self.isWaitingForValue = false
    }




    // ---------------------------- Handle button press, "start exercise" and "cancel" -------

    func cancelPressed() {
        isDoneWithAllRep = false
        if (conn != nil) {
            conn.inputStream!.close()
            conn.outputStream!.close()
            conn.inputStream!.removeFromRunLoop(.mainRunLoop(), forMode: NSDefaultRunLoopMode)
            conn.outputStream!.removeFromRunLoop(.mainRunLoop(), forMode: NSDefaultRunLoopMode)
            conn = nil
        }
        self.performSegueWithIdentifier("showMenu", sender: self)
    }
    
    func startPressed() {
        if (!isWaitingForValue) {
            if (connectStatusServer || connectStatusBLE) {
                if (count == 0) {
                    if let number = Int(repNumber.text!) {
                        if number > 20 {
                            rows = 20
                            repNumber.text = "20"
                            repNumber.placeholder = "20"
                        } else if number < 1{
                            rows = 10
                            repNumber.text = "10"
                            repNumber.placeholder = "10"
                        } else {
                            rows = number
                        }
                    } else {
                        showNotAValidNumberErrorAlert()
                        return
                    }
                    if (exerciseNr! == 3 || exerciseNr! == 9) {
                        rows = 10
                        repNumber.text = "10"
                        repNumber.placeholder = "10"
                    }
                    let tempArr = Array(count: self.rows, repeatedValue: Array(count: self.cols, repeatedValue: 0.0))
                    data += tempArr
                } else if (count == rows-1) {
                    isDoneWithAllRep = true
                } else if (isDoneWithAllRep) {
                    self.performSegueWithIdentifier("showMenu", sender: self)
                }
                if (count < rows) {
                    let str: String = NSString(format: "%d", exerciseNr!) as String
                    if (connectStatusServer) {
                        conn.sendData(str)
                        print("Send " + "\(exerciseNr!)")
                    } else if (connectStatusBLE) {
                        let data:NSData = ("0" as NSString).dataUsingEncoding(NSUTF8StringEncoding)!
                        ble.write(data) // send a 0 to start the ball time
                    }
                }
                isWaitingForValue = true
                buttonText!.text = "Waiting"
            } else {
                if isKinectExercise {
                    showServerNotConnectedErrorAlert()
                } else {
                    showBLENotConnectedErrorAlert()
                }
            }
        }
    }
    // ---------------------------------------------------------------------------------------
    
    
    // ------------------------ Math methods and segue to the main menu ----------------------
    
    func getAverage() -> Double {
        var sum: Double = 0
        for i in 0...rows-1 {
            sum += data[i][cols-1]
        }
        var average: Double = 0
        if isDoneWithAllRep {
            average = sum/(Double(rows))
        } else {
            average = sum/(Double(count+1))
        }
        return average
    }
    
    func getR(x: Double, y: Double) -> Double {
        return sqrt(pow(x, 2)+pow(y,2))
    }
    
    // Go back to the main menu
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(segue.identifier == "showMenu") {
            let vc_ny = (segue.destinationViewController as! ViewController)
            if isDoneWithAllRep {
                vc_ny.data = data
                vc_ny.addToTableBool = isDoneWithAllRep
                vc_ny.tableImage = UIImage(named: String(format: "tblOvn%d", exerciseNr!))
                vc_ny.tableExercise = exerciseTitleVar
                if nameInput.text != "" {
                    vc_ny.tableName = nameInput.text!
                } else {
                    vc_ny.tableName = "Unknown"
                }
                if isTimeExercise {
                    vc_ny.tableAverage = String(format: "%.1f s", getAverage())
                } else {
                    vc_ny.tableAverage = String(format: "%.1f m", getAverage())
                }
            }
            vc_ny.host = self.host!
            
            if (connectStatusBLE) {
                ble.CM.cancelPeripheralConnection(ble.activePeripheral)
            }
        }
    }
    // ----------------------------------------------------------------------------------------
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

